<?php
require_once 'includes/auth_check.php';
require_once 'includes/header.php';
$page_title = 'Отчеты';
?>

<div class="container mt-4">
    <!-- Добавленная кнопка "Назад" -->
    <div class="mb-4">
        <a href="index.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Назад
        </a>
    </div>
    
    <h1><i class="fas fa-chart-bar"></i> Отчеты</h1>
    
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title">Мероприятия</h5>
                </div>
                <div class="card-body">
                    <p>Отчеты по проведенным мероприятиям</p>
                    <a href="report_events.php" class="btn btn-outline-primary">Перейти</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-header bg-success text-white">
                    <h5 class="card-title">Кураторские часы</h5>
                </div>
                <div class="card-body">
                    <p>Отчеты по проведенным кураторским часам</p>
                    <a href="report_curator_hours.php" class="btn btn-outline-success">Перейти</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-header bg-secondary text-white">
                    <h5 class="card-title">Уборки</h5>
                </div>
                <div class="card-body">
                    <p>Отчеты по выполненным уборкам</p>
                    <a href="report_cleanings.php" class="btn btn-outline-secondary">Перейти</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>