document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const mainContent = document.querySelector('.main-content');
    const header = document.querySelector('.header');

    // Проверяем сохраненное состояние
    const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    if (isCollapsed) {
        sidebar.classList.add('collapsed');
        document.querySelector('.sidebar-logo').style.display = 'none';
        sidebarToggle.innerHTML = '<i class="fas fa-angle-double-right"></i>';
    }

    // Обработчик кнопки сворачивания
    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
        
        const isNowCollapsed = sidebar.classList.contains('collapsed');
        localStorage.setItem('sidebarCollapsed', isNowCollapsed);
        
        if (isNowCollapsed) {
            document.querySelector('.sidebar-logo').style.display = 'none';
            sidebarToggle.innerHTML = '<i class="fas fa-angle-double-right"></i>';
        } else {
            document.querySelector('.sidebar-logo').style.display = 'block';
            sidebarToggle.innerHTML = '<i class="fas fa-angle-double-left"></i>';
        }
    });

    // Адаптация для мобильных устройств
    function handleMobileView() {
        if (window.innerWidth <= 992) {
            sidebar.classList.remove('active');
            sidebar.classList.add('collapsed');
        } else {
            const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
            if (isCollapsed) {
                sidebar.classList.add('collapsed');
            } else {
                sidebar.classList.remove('collapsed');
            }
        }
    }

    window.addEventListener('resize', handleMobileView);
    handleMobileView();
});
// Мобильное меню
document.querySelector('.mobile-sidebar-toggle').addEventListener('click', function() {
    const sidebar = document.getElementById('sidebar');
    if (window.innerWidth <= 992) {
        sidebar.classList.toggle('active');
    }
});