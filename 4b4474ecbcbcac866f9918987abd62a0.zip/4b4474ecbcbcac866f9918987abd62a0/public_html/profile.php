<?php
require_once 'includes/auth_check.php';
require_once 'includes/header.php';
$page_title = 'Мой профиль';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = trim($_POST['firstName']);
    $lastName = trim($_POST['lastName']);
    $middleName = trim($_POST['middleName']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $params = [$firstName, $lastName, $middleName, $email, $curator_id];
    $sql = "UPDATE curators SET firstName = ?, lastName = ?, middleName = ?, email = ?";

    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql .= ", password = ?";
        $params[] = $hashedPassword;
    }

    $sql .= " WHERE id = ?";

    $stmt = $conn->prepare($sql);
    if ($stmt->execute($params)) {
        $_SESSION['success_message'] = "Профиль успешно обновлен";
        header("Location: profile.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Ошибка при обновлении профиля";
    }
}
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><i class="fas fa-user-cog"></i> Мой профиль</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label for="lastName" class="form-label">Фамилия</label>
                            <input type="text" class="form-control" id="lastName" name="lastName" 
                                   value="<?= htmlspecialchars($curator['lastName']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="firstName" class="form-label">Имя</label>
                            <input type="text" class="form-control" id="firstName" name="firstName" 
                                   value="<?= htmlspecialchars($curator['firstName']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="middleName" class="form-label">Отчество</label>
                            <input type="text" class="form-control" id="middleName" name="middleName" 
                                   value="<?= htmlspecialchars($curator['middleName'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?= htmlspecialchars($curator['email']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Новый пароль (оставьте пустым, чтобы не менять)</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <button type="submit" class="btn btn-primary">Сохранить изменения</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>