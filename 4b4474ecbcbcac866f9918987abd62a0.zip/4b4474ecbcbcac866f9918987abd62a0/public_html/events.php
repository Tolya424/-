<?php
require_once 'includes/auth_check.php';
require_once 'includes/header.php';
$page_title = 'Мероприятия';

// Получаем мероприятия
$stmt = $conn->prepare("
    SELECT e.*, g.group_number 
    FROM events e
    JOIN student_groups g ON e.group_id = g.id
    WHERE g.curator_id = ?
    ORDER BY e.event_date DESC, e.event_time DESC
");
$stmt->execute([$curator_id]);
$events = $stmt->fetchAll();
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <a href="index.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
            <h1 class="d-inline-block mb-0"><i class="fas fa-calendar-alt"></i> Мероприятия</h1>
        </div>
        
    </div>

    <div class="card">
        <div class="card-body">
            <?php if ($events): ?>
                <div class="list-group">
                    <?php foreach ($events as $event): ?>
                        <a href="event_view.php?id=<?= $event['id'] ?>" class="list-group-item list-group-item-action">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="mb-1"><?= htmlspecialchars($event['title']) ?></h5>
                                    <small class="text-muted">
                                        <?= date('d.m.Y', strtotime($event['event_date'])) ?>
                                        <?= $event['event_time'] ? 'в ' . date('H:i', strtotime($event['event_time'])) : '' ?>
                                    </small>
                                    <div class="mt-1">
                                        <span class="badge bg-light text-dark">
                                            <?= htmlspecialchars($event['group_number']) ?>
                                        </span>
                                    </div>
                                </div>
                                <i class="fas fa-chevron-right text-muted"></i>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">Нет мероприятий</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php 
require_once 'includes/modals.php';
require_once 'includes/footer.php';
?>