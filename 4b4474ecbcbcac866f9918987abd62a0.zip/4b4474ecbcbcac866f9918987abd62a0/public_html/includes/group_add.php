<?php
require_once 'includes/auth_check.php';
require_once 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $group_number = trim($_POST['group_number']);
    $leader_name = trim($_POST['leader_name']);
    $leader_phone = trim($_POST['leader_phone']);
    $students = trim($_POST['students']);
    $curator_id = $_POST['curator_id'];

    // Для обычных кураторов проверяем, что они добавляют группу себе
    if (!$is_admin && $curator_id != $_SESSION['curator_id']) {
        $_SESSION['error_message'] = "Ошибка доступа";
        header("Location: groups.php");
        exit();
    }

    try {
        $stmt = $conn->prepare("
            INSERT INTO student_groups (group_number, curator_id, leader_name, leader_phone, students)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$group_number, $curator_id, $leader_name, $leader_phone, $students]);
        
        $_SESSION['success_message'] = "Группа успешно добавлена";
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Ошибка дублирования
            $_SESSION['error_message'] = "Группа с таким номером уже существует";
        } else {
            $_SESSION['error_message'] = "Ошибка при добавлении группы";
        }
    }
    
    header("Location: groups.php");
    exit();
} else {
    header("Location: groups.php");
    exit();
}
?>