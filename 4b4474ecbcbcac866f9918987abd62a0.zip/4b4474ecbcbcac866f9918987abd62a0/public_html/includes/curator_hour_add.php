<?php
require_once 'includes/auth_check.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $topic = trim($_POST['topic']);
    $description = trim($_POST['description']);
    $event_date = $_POST['event_date'];
    $group_id = $_POST['group_id'];

    // Проверка доступа к группе
    $stmt = $conn->prepare("SELECT id FROM student_groups WHERE id = ? AND curator_id = ?");
    $stmt->execute([$group_id, $curator_id]);
    
    if ($stmt->fetch()) {
        $stmt = $conn->prepare("
            INSERT INTO curator_hours (topic, description, event_date, group_id, created_by)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$topic, $description, $event_date, $group_id, $curator_id]);
        
        $_SESSION['success_message'] = "Кураторский час успешно добавлен";
        header("Location: curator_hours.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Ошибка доступа к группе";
        header("Location: curator_hours.php");
        exit();
    }
} else {
    header("Location: curator_hours.php");
    exit();
}
?>