<div class="sidebar" id="sidebar">
    <div class="sidebar-header d-flex justify-content-between align-items-center p-3">
        <span class="sidebar-logo" style="display: <?= $_SESSION['sidebar_collapsed'] ?? false ? 'none' : 'block' ?>">
            Личный кабинет
        </span>
        <button class="btn btn-sm btn-toggle" id="sidebarToggle">
            <i class="fas <?= ($_SESSION['sidebar_collapsed'] ?? false) ? 'fa-angle-double-right' : 'fa-angle-double-left' ?>"></i>
        </button>
    </div>
    <ul class="sidebar-menu">
        <li class="<?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>">
            <a href="index.php">
                <i class="fas fa-home me-3"></i>
                <span class="menu-text">Главная</span>
            </a>
        </li>
        <li class="<?= basename($_SERVER['PHP_SELF']) == 'events.php' ? 'active' : '' ?>">
            <a href="events.php">
                <i class="fas fa-calendar-alt me-3"></i>
                <span class="menu-text">Мероприятия</span>
            </a>
        </li>
        <!-- Остальные пункты меню -->
    </ul>
</div>