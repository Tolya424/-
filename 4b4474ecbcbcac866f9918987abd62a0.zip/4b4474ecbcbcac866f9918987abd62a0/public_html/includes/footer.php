<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет куратора</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        .main-content {
            flex: 1 0 auto;
            padding-bottom: 60px; /* Отступ для футера */
        }
        .footer {
            flex-shrink: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="main-content">
        <!-- Здесь основной контент вашей страницы -->
    </div>

    <!-- Footer -->
    <footer class="footer py-3 bg-light border-top">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <span class="text-muted">
                        &copy; <?php echo date('Y'); ?> Личный кабинет куратора. Все права защищены.
                    </span>
                </div>
                <div class="col-md-6 text-md-end">
                    <span class="text-muted">
                        Версия 1.0.0 | 
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#aboutModal">
                            О системе
                        </a>
                    </span>
                </div>
            </div>
        </div>
    </footer>

    <!-- Модальное окно "О системе" -->
    <div class="modal fade" id="aboutModal" tabindex="-1" aria-labelledby="aboutModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="aboutModalLabel"><i class="fas fa-info-circle me-2"></i>О системе</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3 text-center">
                        <i class="fas fa-user-graduate fa-4x text-primary mb-3"></i>
                        <h4>Личный кабинет куратора</h4>
                        <p class="text-muted">Версия 1.0.0</p>
                    </div>
                    <hr>
                    <div class="mb-3">
                        <h6><i class="fas fa-feather-alt me-2"></i>Функционал системы:</h6>
                        <ul>
                            <li>Управление группами студентов</li>
                            <li>Планирование мероприятий</li>
                            <li>Организация кураторских часов</li>
                            <li>Контроль уборок</li>
                            <li>Формирование отчетов</li>
                        </ul>
                    </div>
                    <div class="mb-3">
                        <h6><i class="fas fa-cogs me-2"></i>Техническая информация:</h6>
                        <p class="small mb-1">
                            <strong>PHP:</strong> <?php echo phpversion(); ?>
                        </p>
                        <p class="small mb-1">
                            <strong>Сервер:</strong> <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Неизвестно'; ?>
                        </p>
                        <p class="small">
                            <strong>База данных:</strong> MySQL
                        </p>
                    </div>
                    <hr>
                    <div class="text-center text-muted small">
                        <p class="mb-0">По всем вопросам обращайтесь в техническую поддержку</p>
                        <p class="mb-0">
                            <i class="fas fa-envelope me-1"></i> 
                        </p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Закрыть</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Скрипты -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
</body>
</html>