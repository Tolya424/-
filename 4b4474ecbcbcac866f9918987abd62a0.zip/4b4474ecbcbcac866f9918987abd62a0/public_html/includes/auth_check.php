<?php
session_start();
if (!isset($_SESSION['curator_id'])) {
    header("Location: login.php");
    exit();
}

$is_admin = $_SESSION['is_admin'] ?? false;
$curator_id = $_SESSION['curator_id'];

// Получаем данные куратора
include_once 'db.php';
$stmt = $conn->prepare("SELECT * FROM curators WHERE id = ?");
$stmt->execute([$curator_id]);
$curator = $stmt->fetch();
?>