<!-- Модальное окно добавления мероприятия -->
<div class="modal fade" id="addEventModal" tabindex="-1" aria-labelledby="addEventModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addEventModalLabel">Добавить мероприятие</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="event_add.php" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="eventTitle" class="form-label">Название</label>
                        <input type="text" class="form-control" id="eventTitle" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="eventDescription" class="form-label">Описание</label>
                        <textarea class="form-control" id="eventDescription" name="description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="eventDate" class="form-label">Дата</label>
                        <input type="date" class="form-control" id="eventDate" name="event_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="eventTime" class="form-label">Время</label>
                        <input type="time" class="form-control" id="eventTime" name="event_time">
                    </div>
                    <div class="mb-3">
                        <label for="eventGroup" class="form-label">Группа</label>
                        <select class="form-select" id="eventGroup" name="group_id" required>
                            <?php foreach ($student_groups as $group): ?>
                                <option value="<?= $group['id'] ?>"><?= htmlspecialchars($group['group_number']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                    <button type="submit" class="btn btn-primary">Добавить</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Модальное окно добавления кураторского часа -->
<div class="modal fade" id="addCuratorHourModal" tabindex="-1" aria-labelledby="addCuratorHourModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="addCuratorHourModalLabel">
                    <i class="fas fa-chalkboard-teacher me-2"></i>Добавить кураторский час
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="curator_hour_add.php" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="curatorHourTopic" class="form-label">Тема</label>
                        <input type="text" class="form-control" id="curatorHourTopic" name="topic" required>
                    </div>
                    <div class="mb-3">
                        <label for="curatorHourDescription" class="form-label">Описание</label>
                        <textarea class="form-control" id="curatorHourDescription" name="description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="curatorHourDate" class="form-label">Дата проведения</label>
                        <input type="date" class="form-control" id="curatorHourDate" name="event_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="curatorHourGroup" class="form-label">Группа</label>
                        <select class="form-select" id="curatorHourGroup" name="group_id" required>
                            <?php foreach ($student_groups as $group): ?>
                                <option value="<?= $group['id'] ?>"><?= htmlspecialchars($group['group_number']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                    <button type="submit" class="btn btn-success">Добавить</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Модальное окно добавления уборки -->
<div class="modal fade" id="addCleaningModal" tabindex="-1" aria-labelledby="addCleaningModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-secondary text-white">
                <h5 class="modal-title" id="addCleaningModalLabel">
                    <i class="fas fa-broom me-2"></i>Добавить уборку
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="cleaning_add.php" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="cleaningLocation" class="form-label">Место уборки</label>
                        <input type="text" class="form-control" id="cleaningLocation" name="location" required>
                    </div>
                    <div class="mb-3">
                        <label for="cleaningDate" class="form-label">Дата уборки</label>
                        <input type="date" class="form-control" id="cleaningDate" name="cleaning_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="cleaningGroup" class="form-label">Группа</label>
                        <select class="form-select" id="cleaningGroup" name="group_id" required>
                            <?php foreach ($student_groups as $group): ?>
                                <option value="<?= $group['id'] ?>"><?= htmlspecialchars($group['group_number']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                    <button type="submit" class="btn btn-secondary">Добавить</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Модальное окно добавления группы -->
<div class="modal fade" id="addGroupModal" tabindex="-1" aria-labelledby="addGroupModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addGroupModalLabel">
                    <i class="fas fa-users me-2"></i>Добавить группу
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="group_add.php" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="groupNumber" class="form-label">Номер группы</label>
                        <input type="text" class="form-control" id="groupNumber" name="group_number" required>
                    </div>
                    <div class="mb-3">
                        <label for="leaderName" class="form-label">ФИО старосты</label>
                        <input type="text" class="form-control" id="leaderName" name="leader_name">
                    </div>
                    <div class="mb-3">
                        <label for="leaderPhone" class="form-label">Телефон старосты</label>
                        <input type="tel" class="form-control" id="leaderPhone" name="leader_phone">
                    </div>
                    <div class="mb-3">
                        <label for="studentsList" class="form-label">Список студентов (через запятую)</label>
                        <textarea class="form-control" id="studentsList" name="students" rows="5" placeholder="Иванов Иван, Петров Петр, Сидорова Анна"></textarea>
                    </div>
                    <?php if ($is_admin): ?>
                    <div class="mb-3">
                        <label for="groupCurator" class="form-label">Куратор</label>
                        <select class="form-select" id="groupCurator" name="curator_id" required>
                            <?php 
                            $stmt = $conn->query("SELECT id, lastName, firstName FROM curators");
                            $curators_list = $stmt->fetchAll();
                            foreach ($curators_list as $curator_item): 
                            ?>
                                <option value="<?= $curator_item['id'] ?>" <?= $curator_item['id'] == $curator_id ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($curator_item['lastName'] . ' ' . $curator_item['firstName']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php else: ?>
                        <input type="hidden" name="curator_id" value="<?= $curator_id ?>">
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                    <button type="submit" class="btn btn-primary">Добавить</button>
                </div>
            </form>
        </div>
    </div>
</div>