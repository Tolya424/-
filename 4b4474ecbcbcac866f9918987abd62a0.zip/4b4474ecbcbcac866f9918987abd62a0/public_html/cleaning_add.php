<?php
require_once 'includes/auth_check.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $location = trim($_POST['location']);
    $cleaning_date = $_POST['cleaning_date'];
    $group_id = $_POST['group_id'];

    // Проверка доступа к группе
    $stmt = $conn->prepare("SELECT id FROM student_groups WHERE id = ? AND curator_id = ?");
    $stmt->execute([$group_id, $curator_id]);
    
    if ($stmt->fetch()) {
        $stmt = $conn->prepare("
            INSERT INTO cleanings (location, cleaning_date, group_id, created_by)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$location, $cleaning_date, $group_id, $curator_id]);
        
        $_SESSION['success_message'] = "Уборка успешно добавлена";
        header("Location: cleanings.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Ошибка доступа к группе";
        header("Location: cleanings.php");
        exit();
    }
} else {
    header("Location: cleanings.php");
    exit();
}
?>