<?php
require_once 'includes/auth_check.php';
require_once 'includes/db.php';
require_once 'includes/header.php';

$group_id = $_GET['id'] ?? 0;

// Проверяем доступ к группе
if ($is_admin) {
    $stmt = $conn->prepare("
        SELECT g.*, c.lastName as curator_lastName, c.firstName as curator_firstName
        FROM student_groups g
        JOIN curators c ON g.curator_id = c.id
        WHERE g.id = ?
    ");
    $stmt->execute([$group_id]);
} else {
    $stmt = $conn->prepare("
        SELECT g.*, c.lastName as curator_lastName, c.firstName as curator_firstName
        FROM student_groups g
        JOIN curators c ON g.curator_id = c.id
        WHERE g.id = ? AND g.curator_id = ?
    ");
    $stmt->execute([$group_id, $curator_id]);
}

$group = $stmt->fetch();

if (!$group) {
    $_SESSION['error_message'] = "Группа не найдена или нет доступа";
    header("Location: groups.php");
    exit();
}

$page_title = 'Группа ' . htmlspecialchars($group['group_number']);
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-users me-2"></i>
            Группа <?= htmlspecialchars($group['group_number']) ?>
        </h1>
        <div>
            <a href="group_edit.php?id=<?= $group['id'] ?>" class="btn btn-warning me-2">
                <i class="fas fa-edit me-1"></i> Редактировать
            </a>
            <a href="groups.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Назад
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-info-circle me-2"></i> Основная информация
                    </h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <th width="40%">Номер группы:</th>
                            <td><?= htmlspecialchars($group['group_number']) ?></td>
                        </tr>
                        <tr>
                            <th>Куратор:</th>
                            <td><?= htmlspecialchars($group['curator_lastName'] . ' ' . $group['curator_firstName']) ?></td>
                        </tr>
                        <tr>
                            <th>Староста:</th>
                            <td><?= $group['leader_name'] ? htmlspecialchars($group['leader_name']) : '<span class="text-muted">Не указан</span>' ?></td>
                        </tr>
                        <tr>
                            <th>Телефон старосты:</th>
                            <td><?= $group['leader_phone'] ? htmlspecialchars($group['leader_phone']) : '<span class="text-muted">Не указан</span>' ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-user-graduate me-2"></i> Список студентов
                    </h5>
                </div>
                <div class="card-body">
                    <?php if ($group['students']): ?>
                        <div class="list-group">
                            <?php 
                            $students = array_filter(explode(',', $group['students']));
                            foreach ($students as $student): 
                                $student = trim($student);
                                if ($student): ?>
                                    <div class="list-group-item">
                                        <?= htmlspecialchars($student) ?>
                                    </div>
                                <?php endif;
                            endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info mb-0">
                            Список студентов не заполнен
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>