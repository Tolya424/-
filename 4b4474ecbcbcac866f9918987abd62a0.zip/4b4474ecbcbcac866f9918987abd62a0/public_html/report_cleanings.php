<?php
require_once 'includes/auth_check.php';
require_once 'includes/db.php';
require_once 'includes/header.php';

$page_title = 'Отчет по уборкам';

// Фильтры
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');
$group_id = $_GET['group_id'] ?? null;

// Получаем данные об уборках
$sql = "
    SELECT cl.*, g.group_number 
    FROM cleanings cl
    JOIN student_groups g ON cl.group_id = g.id
    WHERE g.curator_id = ? 
    AND cl.cleaning_date BETWEEN ? AND ?
";

$params = [$curator_id, $start_date, $end_date];

if ($group_id) {
    $sql .= " AND cl.group_id = ?";
    $params[] = $group_id;
}

$sql .= " ORDER BY cl.cleaning_date DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$cleanings = $stmt->fetchAll();

// Получаем список групп для фильтра
$stmt = $conn->prepare("SELECT id, group_number FROM student_groups WHERE curator_id = ? ORDER BY group_number");
$stmt->execute([$curator_id]);
$groups = $stmt->fetchAll();
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-broom"></i> Отчет по уборкам</h1>
        <div>
            <button class="btn btn-primary me-2" onclick="window.print()">
                <i class="fas fa-print"></i> Печать
            </button>
            <a href="reports.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>

    <!-- Фильтры -->
    <div class="card mb-4">
        <div class="card-header bg-secondary text-white">
            <h5 class="card-title mb-0"><i class="fas fa-filter"></i> Фильтры</h5>
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label for="start_date" class="form-label">Дата с</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" value="<?= $start_date ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">Дата по</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" value="<?= $end_date ?>">
                </div>
                <div class="col-md-4">
                    <label for="group_id" class="form-label">Группа</label>
                    <select class="form-select" id="group_id" name="group_id">
                        <option value="">Все группы</option>
                        <?php foreach ($groups as $group): ?>
                            <option value="<?= $group['id'] ?>" <?= $group_id == $group['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($group['group_number']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-secondary w-100">
                        <i class="fas fa-search"></i> Применить
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Результаты -->
    <div class="card">
        <div class="card-body">
            <?php if ($cleanings): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Дата</th>
                                <th>Место уборки</th>
                                <th>Группа</th>
                                <th>Ответственный</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cleanings as $cleaning): ?>
                                <tr>
                                    <td><?= date('d.m.Y', strtotime($cleaning['cleaning_date'])) ?></td>
                                    <td><?= htmlspecialchars($cleaning['location']) ?></td>
                                    <td><?= htmlspecialchars($cleaning['group_number']) ?></td>
                                    <td>
                                        <?php
                                        $stmt = $conn->prepare("SELECT lastName, firstName FROM curators WHERE id = ?");
                                        $stmt->execute([$cleaning['created_by']]);
                                        $creator = $stmt->fetch();
                                        echo htmlspecialchars($creator['lastName'] . ' ' . $creator['firstName']);
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    Нет данных об уборках за выбранный период
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>