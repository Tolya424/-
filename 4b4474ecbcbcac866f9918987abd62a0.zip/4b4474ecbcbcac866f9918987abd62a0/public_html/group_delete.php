<?php
require_once 'includes/auth_check.php';
require_once 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $group_id = $_POST['id'] ?? 0;
    
    // Проверяем существование группы и права доступа
    if ($is_admin) {
        $stmt = $conn->prepare("SELECT id FROM student_groups WHERE id = ?");
        $stmt->execute([$group_id]);
    } else {
        $stmt = $conn->prepare("SELECT id FROM student_groups WHERE id = ? AND curator_id = ?");
        $stmt->execute([$group_id, $curator_id]);
    }
    
    $group = $stmt->fetch();
    
    if ($group) {
        try {
            // Удаляем связанные записи (если нужно)
            $conn->beginTransaction();
            
            // Удаляем мероприятия группы
            $stmt = $conn->prepare("DELETE FROM events WHERE group_id = ?");
            $stmt->execute([$group_id]);
            
            // Удаляем кураторские часы группы
            $stmt = $conn->prepare("DELETE FROM curator_hours WHERE group_id = ?");
            $stmt->execute([$group_id]);
            
            // Удаляем уборки группы
            $stmt = $conn->prepare("DELETE FROM cleanings WHERE group_id = ?");
            $stmt->execute([$group_id]);
            
            // Удаляем саму группу
            $stmt = $conn->prepare("DELETE FROM student_groups WHERE id = ?");
            $stmt->execute([$group_id]);
            
            $conn->commit();
            
            $_SESSION['success_message'] = "Группа и все связанные данные успешно удалены";
        } catch (PDOException $e) {
            $conn->rollBack();
            $_SESSION['error_message'] = "Ошибка при удалении группы: " . $e->getMessage();
        }
    } else {
        $_SESSION['error_message'] = "Группа не найдена или нет доступа";
    }
}

header("Location: groups.php");
exit();
?>