<?php
require_once 'includes/auth_check.php';
require_once 'includes/db.php';

$group_id = $_GET['id'] ?? 0;

// Проверяем доступ к группе
if ($is_admin) {
    $stmt = $conn->prepare("SELECT * FROM student_groups WHERE id = ?");
    $stmt->execute([$group_id]);
} else {
    $stmt = $conn->prepare("SELECT * FROM student_groups WHERE id = ? AND curator_id = ?");
    $stmt->execute([$group_id, $curator_id]);
}

$group = $stmt->fetch();

if (!$group) {
    $_SESSION['error_message'] = "Группа не найдена или нет доступа";
    header("Location: groups.php");
    exit();
}

// Обработка формы редактирования
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $group_number = trim($_POST['group_number']);
    $leader_name = trim($_POST['leader_name']);
    $leader_phone = trim($_POST['leader_phone']);
    $students = trim($_POST['students']);
    
    // Для обычных кураторов проверяем, что они редактируют свою группу
    if (!$is_admin && $group['curator_id'] != $curator_id) {
        $_SESSION['error_message'] = "Ошибка доступа";
        header("Location: groups.php");
        exit();
    }

    try {
        $stmt = $conn->prepare("
            UPDATE student_groups SET
                group_number = ?,
                leader_name = ?,
                leader_phone = ?,
                students = ?
            WHERE id = ?
        ");
        $stmt->execute([$group_number, $leader_name, $leader_phone, $students, $group_id]);
        
        $_SESSION['success_message'] = "Группа успешно обновлена";
        header("Location: group_view.php?id=" . $group_id);
        exit();
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            $_SESSION['error_message'] = "Группа с таким номером уже существует";
        } else {
            $_SESSION['error_message'] = "Ошибка при обновлении группы";
        }
        header("Location: group_edit.php?id=" . $group_id);
        exit();
    }
}

require_once 'includes/header.php';
$page_title = 'Редактирование группы ' . htmlspecialchars($group['group_number']);
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-edit me-2"></i>
            Редактирование группы <?= htmlspecialchars($group['group_number']) ?>
        </h1>
        <a href="group_view.php?id=<?= $group['id'] ?>" class="btn btn-secondary">
            <i class="fas fa-times me-1"></i> Отмена
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="groupNumber" class="form-label">Номер группы</label>
                            <input type="text" class="form-control" id="groupNumber" name="group_number" 
                                   value="<?= htmlspecialchars($group['group_number']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="leaderName" class="form-label">ФИО старосты</label>
                            <input type="text" class="form-control" id="leaderName" name="leader_name" 
                                   value="<?= htmlspecialchars($group['leader_name'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label for="leaderPhone" class="form-label">Телефон старосты</label>
                            <input type="tel" class="form-control" id="leaderPhone" name="leader_phone" 
                                   value="<?= htmlspecialchars($group['leader_phone'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="studentsList" class="form-label">Список студентов (через запятую)</label>
                            <textarea class="form-control" id="studentsList" name="students" rows="5"
                                      style="min-height: 200px;"><?= htmlspecialchars($group['students'] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-3">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Сохранить изменения
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Маска для телефона
    const phoneInput = document.getElementById('leaderPhone');
    phoneInput.addEventListener('input', function(e) {
        const x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
    });

    // Автоматическое приведение номера группы к верхнему регистру
    document.getElementById('groupNumber').addEventListener('input', function(e) {
        e.target.value = e.target.value.toUpperCase();
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>