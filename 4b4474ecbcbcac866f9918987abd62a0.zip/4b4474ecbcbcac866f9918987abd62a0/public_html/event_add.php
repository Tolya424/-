<?php
require_once 'includes/auth_check.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $event_date = $_POST['event_date'];
    $event_time = $_POST['event_time'] ?? null;
    $group_id = $_POST['group_id'];

    // Проверка что группа принадлежит куратору
    $stmt = $conn->prepare("SELECT id FROM student_groups WHERE id = ? AND curator_id = ?");
    $stmt->execute([$group_id, $curator_id]);
    
    if ($stmt->fetch()) {
        $stmt = $conn->prepare("
            INSERT INTO events (title, description, event_date, event_time, group_id, created_by)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$title, $description, $event_date, $event_time, $group_id, $curator_id]);
        
        $_SESSION['success_message'] = "Мероприятие успешно добавлено";
        header("Location: events.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Ошибка доступа к группе";
        header("Location: events.php");
        exit();
    }
} else {
    header("Location: events.php");
    exit();
}
?>