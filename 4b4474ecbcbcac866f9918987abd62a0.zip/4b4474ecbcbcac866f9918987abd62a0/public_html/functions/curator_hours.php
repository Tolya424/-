<?php
require_once 'includes/auth_check.php';
require_once 'includes/header.php';
$page_title = 'Кураторские часы';

// Получаем кураторские часы
$stmt = $conn->prepare("
    SELECT ch.*, g.group_number 
    FROM curator_hours ch
    JOIN student_groups g ON ch.group_id = g.id
    WHERE g.curator_id = ?
    ORDER BY ch.event_date DESC
");
$stmt->execute([$curator_id]);
$hours = $stmt->fetchAll();
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-chalkboard-teacher"></i> Кураторские часы</h1>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCuratorHourModal">
            <i class="fas fa-plus"></i> Добавить
        </button>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if ($hours): ?>
                <div class="list-group">
                    <?php foreach ($hours as $hour): ?>
                        <a href="curator_hour_view.php?id=<?= $hour['id'] ?>" class="list-group-item list-group-item-action">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h5><?= htmlspecialchars($hour['topic']) ?></h5>
                                    <small class="text-muted">
                                        <?= date('d.m.Y', strtotime($hour['event_date'])) ?>
                                    </small>
                                    <?php if ($hour['description']): ?>
                                        <p class="mb-0 text-truncate"><?= htmlspecialchars($hour['description']) ?></p>
                                    <?php endif; ?>
                                </div>
                                <span class="badge bg-success"><?= htmlspecialchars($hour['group_number']) ?></span>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">Нет запланированных кураторских часов</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php 
require_once 'includes/modals.php';
require_once 'includes/footer.php';
?>