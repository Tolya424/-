<?php
require_once 'includes/auth_check.php';
require_once 'includes/header.php';
$page_title = 'Мероприятия';

// Получаем мероприятия
$stmt = $conn->prepare("
    SELECT e.*, g.group_number 
    FROM events e
    JOIN student_groups g ON e.group_id = g.id
    WHERE g.curator_id = ?
    ORDER BY e.event_date DESC, e.event_time DESC
");
$stmt->execute([$curator_id]);
$events = $stmt->fetchAll();
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-calendar-alt"></i> Мероприятия</h1>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEventModal">
            <i class="fas fa-plus"></i> Добавить
        </button>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if ($events): ?>
                <div class="list-group">
                    <?php foreach ($events as $event): ?>
                        <a href="event_view.php?id=<?= $event['id'] ?>" class="list-group-item list-group-item-action">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h5><?= htmlspecialchars($event['title']) ?></h5>
                                    <small class="text-muted">
                                        <?= date('d.m.Y', strtotime($event['event_date'])) ?>
                                        <?= $event['event_time'] ? 'в ' . date('H:i', strtotime($event['event_time'])) : '' ?>
                                    </small>
                                </div>
                                <span class="badge bg-primary"><?= htmlspecialchars($event['group_number']) ?></span>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">Нет мероприятий</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php 
require_once 'includes/modals.php';
require_once 'includes/footer.php';
?>