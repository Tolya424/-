<?php
require_once 'includes/auth_check.php';
require_once 'includes/header.php';
$page_title = 'Уборки';

// Получаем уборки
$stmt = $conn->prepare("
    SELECT cl.*, g.group_number 
    FROM cleanings cl
    JOIN student_groups g ON cl.group_id = g.id
    WHERE g.curator_id = ?
    ORDER BY cl.cleaning_date DESC
");
$stmt->execute([$curator_id]);
$cleanings = $stmt->fetchAll();
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-broom"></i> Уборки</h1>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCleaningModal">
            <i class="fas fa-plus"></i> Добавить
        </button>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if ($cleanings): ?>
                <div class="list-group">
                    <?php foreach ($cleanings as $cleaning): ?>
                        <a href="cleaning_view.php?id=<?= $cleaning['id'] ?>" class="list-group-item list-group-item-action">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h5><?= htmlspecialchars($cleaning['location']) ?></h5>
                                    <small class="text-muted">
                                        <?= date('d.m.Y', strtotime($cleaning['cleaning_date'])) ?>
                                    </small>
                                </div>
                                <span class="badge bg-secondary"><?= htmlspecialchars($cleaning['group_number']) ?></span>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">Нет запланированных уборок</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php 
require_once 'includes/modals.php';
require_once 'includes/footer.php';
?>