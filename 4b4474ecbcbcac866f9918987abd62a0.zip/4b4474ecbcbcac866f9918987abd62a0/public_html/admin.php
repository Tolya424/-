<?php
session_start();
include 'db.php';

if (!isset($_SESSION['curator_id']) || !$_SESSION['is_admin']) {
    header("Location: login.php");
    exit();
}

// Получаем список всех кураторов
$stmt = $conn->query("SELECT * FROM curators ORDER BY lastName, firstName");
$curators = $stmt->fetchAll();

// Получаем список всех групп
$stmt = $conn->query("SELECT g.*, c.lastName as curatorLastName, c.firstName as curatorFirstName FROM student_groups g JOIN curators c ON g.curator_id = c.id ORDER BY g.group_number");
$student_groups = $stmt->fetchAll();

// Обработка добавления нового куратора
if (isset($_POST['add_curator'])) {
    $firstName = trim($_POST['firstName']);
    $lastName = trim($_POST['lastName']);
    $middleName = trim($_POST['middleName']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $is_admin = isset($_POST['is_admin']) ? 1 : 0;
    
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $conn->prepare("INSERT INTO curators (firstName, lastName, middleName, email, password, is_admin) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$firstName, $lastName, $middleName, $email, $hashedPassword, $is_admin]);
    
    $_SESSION['success_message'] = "Куратор успешно добавлен";
    header("Location: admin.php");
    exit();
}

// Обработка удаления куратора
if (isset($_GET['delete_curator'])) {
    $id = $_GET['delete_curator'];
    
    // Нельзя удалить самого себя
    if ($id != $_SESSION['curator_id']) {
        $stmt = $conn->prepare("DELETE FROM curators WHERE id = ?");
        $stmt->execute([$id]);
        
        $_SESSION['success_message'] = "Куратор успешно удален";
    } else {
        $_SESSION['error_message'] = "Вы не можете удалить себя";
    }
    
    header("Location: admin.php");
    exit();
}

// Обработка добавления группы
if (isset($_POST['add_group'])) {
    $group_number = trim($_POST['group_number']);
    $curator_id = $_POST['curator_id'];
    $leader_name = trim($_POST['leader_name']);
    $leader_phone = trim($_POST['leader_phone']);
    $students = trim($_POST['students']);
    
    $stmt = $conn->prepare("INSERT INTO student_groups (group_number, curator_id, leader_name, leader_phone, students) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$group_number, $curator_id, $leader_name, $leader_phone, $students]);
    
    $_SESSION['success_message'] = "Группа успешно добавлена";
    header("Location: admin.php");
    exit();
}

// Обработка удаления группы
if (isset($_GET['delete_group'])) {
    $id = $_GET['delete_group'];
    
    $stmt = $conn->prepare("DELETE FROM student_groups WHERE id = ?");
    $stmt->execute([$id]);
    
    $_SESSION['success_message'] = "Группа успешно удалена";
    header("Location: admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2075d0;
            --primary-hover: #1a65b5;
            --sidebar-width: 250px;
            --header-height: 60px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        /* Сайдбар */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background-color: #2c3e50;
            color: white;
            padding-top: var(--header-height);
            transition: all 0.3s;
            z-index: 1000;
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
        }
        
        .sidebar-menu li {
            padding: 10px 15px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-menu li a {
            color: white;
            text-decoration: none;
            display: block;
        }
        
        .sidebar-menu li:hover {
            background-color: rgba(255,255,255,0.1);
        }
        
        .sidebar-menu li.active {
            background-color: var(--primary-color);
        }
        
        /* Основной контент */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: all 0.3s;
        }
        
        /* Шапка */
        .header {
            position: fixed;
            top: 0;
            left: var(--sidebar-width);
            right: 0;
            height: var(--header-height);
            background-color: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 999;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
        }
        
        /* Карточки */
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
        }
        
        /* Таблицы */
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        /* Кнопки */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
        }
        
        /* Адаптивность */
        @media (max-width: 992px) {
            .sidebar {
                left: -var(--sidebar-width);
            }
            
            .main-content, .header {
                margin-left: 0;
            }
            
            .sidebar.active {
                left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Сайдбар -->
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li class="active">
                <a href="admin.php"><i class="fas fa-tachometer-alt me-2"></i>Панель администратора</a>
            </li>
           
            <li>
                <a href="index.php"><i class="fas fa-user me-2"></i>Мой кабинет</a>
            </li>
            <li>
                <a href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Выйти</a>
            </li>
        </ul>
    </div>

    <!-- Шапка -->
    <header class="header">
        <button class="btn btn-sm btn-outline-secondary d-lg-none" id="sidebarToggle">
            <i class="fas fa-bars"></i>
        </button>
        <div class="d-flex align-items-center">
            <span class="me-3">Администратор</span>
        </div>
    </header>

    <!-- Основной контент -->
    <main class="main-content">
        <div class="container-fluid py-4">
            <!-- Уведомления -->
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <!-- Раздел кураторов -->
            <div class="card mb-4" id="curators-section">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0"><i class="fas fa-users me-2"></i>Управление кураторами</h5>
                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addCuratorModal">
                        <i class="fas fa-plus me-1"></i> Добавить куратора
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>ФИО</th>
                                    <th>Email</th>
                                    <th>Роль</th>
                                    <th>Дата регистрации</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($curators as $curator): ?>
                                    <tr>
                                        <td><?php echo $curator['id']; ?></td>
                                        <td><?php echo htmlspecialchars($curator['lastName'] . ' ' . $curator['firstName'] . ' ' . $curator['middleName']); ?></td>
                                        <td><?php echo htmlspecialchars($curator['email']); ?></td>
                                        <td>
                                            <?php if ($curator['is_admin']): ?>
                                                <span class="badge bg-danger">Администратор</span>
                                            <?php else: ?>
                                                <span class="badge bg-primary">Куратор</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('d.m.Y', strtotime($curator['created_at'])); ?></td>
                                        <td>
                                            <?php if ($curator['id'] != $_SESSION['curator_id']): ?>
                                                <a href="admin.php?delete_curator=<?php echo $curator['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Вы уверены, что хотите удалить этого куратора?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Раздел групп -->
            <div class="card" id="groups-section">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0"><i class="fas fa-users-cog me-2"></i>Управление группами</h5>
                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addGroupModal">
                        <i class="fas fa-plus me-1"></i> Добавить группу
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Номер группы</th>
                                    <th>Куратор</th>
                                    <th>Староста</th>
                                    <th>Телефон старосты</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($student_groups as $group): ?>
                                    <tr>
                                        <td><?php echo $group['id']; ?></td>
                                        <td><?php echo htmlspecialchars($group['group_number']); ?></td>
                                        <td><?php echo htmlspecialchars($group['curatorLastName'] . ' ' . $group['curatorFirstName']); ?></td>
                                        <td><?php echo htmlspecialchars($group['leader_name'] ?? '-'); ?></td>
                                        <td><?php echo htmlspecialchars($group['leader_phone'] ?? '-'); ?></td>
                                        <td>
                                            <a href="admin.php?delete_group=<?php echo $group['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Вы уверены, что хотите удалить эту группу?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Модальное окно добавления куратора -->
    <div class="modal fade" id="addCuratorModal" tabindex="-1" aria-labelledby="addCuratorModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addCuratorModalLabel">Добавить куратора</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="firstName" class="form-label">Имя</label>
                            <input type="text" class="form-control" id="firstName" name="firstName" required>
                        </div>
                        <div class="mb-3">
                            <label for="lastName" class="form-label">Фамилия</label>
                            <input type="text" class="form-control" id="lastName" name="lastName" required>
                        </div>
                        <div class="mb-3">
                            <label for="middleName" class="form-label">Отчество</label>
                            <input type="text" class="form-control" id="middleName" name="middleName">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Пароль</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="is_admin" name="is_admin">
                            <label class="form-check-label" for="is_admin">Администратор</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                        <button type="submit" name="add_curator" class="btn btn-primary">Добавить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Модальное окно добавления группы -->
    <div class="modal fade" id="addGroupModal" tabindex="-1" aria-labelledby="addGroupModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addGroupModalLabel">Добавить группу</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="group_number" class="form-label">Номер группы</label>
                            <input type="text" class="form-control" id="group_number" name="group_number" required>
                        </div>
                        <div class="mb-3">
                            <label for="curator_id" class="form-label">Куратор</label>
                            <select class="form-select" id="curator_id" name="curator_id" required>
                                <?php foreach ($curators as $curator): ?>
                                    <option value="<?php echo $curator['id']; ?>">
                                        <?php echo htmlspecialchars($curator['lastName'] . ' ' . $curator['firstName']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="leader_name" class="form-label">ФИО старосты</label>
                            <input type="text" class="form-control" id="leader_name" name="leader_name">
                        </div>
                        <div class="mb-3">
                            <label for="leader_phone" class="form-label">Телефон старосты</label>
                            <input type="text" class="form-control" id="leader_phone" name="leader_phone">
                        </div>
                        <div class="mb-3">
                            <label for="students" class="form-label">Список студентов (ФИО через запятую)</label>
                            <textarea class="form-control" id="students" name="students" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отмена</button>
                        <button type="submit" name="add_group" class="btn btn-primary">Добавить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Скрипты -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Переключение сайдбара
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    </script>
</body>
</html>