<?php
require_once 'includes/auth_check.php';
require_once 'includes/header.php';
$page_title = 'Кураторские часы';

// Получаем кураторские часы
$stmt = $conn->prepare("
    SELECT ch.*, g.group_number 
    FROM curator_hours ch
    JOIN student_groups g ON ch.group_id = g.id
    WHERE g.curator_id = ?
    ORDER BY ch.event_date DESC
");
$stmt->execute([$curator_id]);
$hours = $stmt->fetchAll();
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <a href="index.php" class="btn btn-outline-secondary btn-sm me-2">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
            <h1 class="d-inline-block mb-0"><i class="fas fa-chalkboard-teacher"></i> Кураторские часы</h1>
        </div>
       
    </div>

    <div class="card">
        <div class="card-body p-0">
            <?php if ($hours): ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($hours as $hour): ?>
                        <a href="curator_hour_view.php?id=<?= $hour['id'] ?>" class="list-group-item list-group-item-action py-3">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="me-3">
                                    <h5 class="mb-1"><?= htmlspecialchars($hour['topic']) ?></h5>
                                    <div class="d-flex align-items-center text-muted small mb-2">
                                        <i class="fas fa-calendar-day me-2"></i>
                                        <?= date('d.m.Y', strtotime($hour['event_date'])) ?>
                                    </div>
                                    <?php if ($hour['description']): ?>
                                        <p class="mb-0 text-muted text-truncate"><?= htmlspecialchars($hour['description']) ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="text-end">
                                    <span class="badge bg-success rounded-pill mb-2"><?= htmlspecialchars($hour['group_number']) ?></span>
                                    <div class="text-muted small">
                                        <i class="fas fa-chevron-right"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info m-3">Нет запланированных кураторских часов</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php 
require_once 'includes/modals.php';
require_once 'includes/footer.php';
?>