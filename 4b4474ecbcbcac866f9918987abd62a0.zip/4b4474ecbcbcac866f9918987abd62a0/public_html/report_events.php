<?php
require_once 'includes/auth_check.php';
require_once 'includes/db.php';
require_once 'includes/header.php';

$page_title = 'Отчет по мероприятиям';

// Фильтры
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');
$group_id = $_GET['group_id'] ?? null;

// Получаем данные о мероприятиях
$sql = "
    SELECT e.*, g.group_number 
    FROM events e
    JOIN student_groups g ON e.group_id = g.id
    WHERE g.curator_id = ? 
    AND e.event_date BETWEEN ? AND ?
";

$params = [$curator_id, $start_date, $end_date];

if ($group_id) {
    $sql .= " AND e.group_id = ?";
    $params[] = $group_id;
}

$sql .= " ORDER BY e.event_date DESC, e.event_time DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$events = $stmt->fetchAll();

// Получаем список групп для фильтра
$stmt = $conn->prepare("SELECT id, group_number FROM student_groups WHERE curator_id = ? ORDER BY group_number");
$stmt->execute([$curator_id]);
$groups = $stmt->fetchAll();
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-calendar-alt"></i> Отчет по мероприятиям</h1>
        <div>
            <button class="btn btn-primary me-2" onclick="window.print()">
                <i class="fas fa-print"></i> Печать
            </button>
            <a href="reports.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>

    <!-- Фильтры -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="card-title mb-0"><i class="fas fa-filter"></i> Фильтры</h5>
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label for="start_date" class="form-label">Дата с</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" value="<?= $start_date ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">Дата по</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" value="<?= $end_date ?>">
                </div>
                <div class="col-md-4">
                    <label for="group_id" class="form-label">Группа</label>
                    <select class="form-select" id="group_id" name="group_id">
                        <option value="">Все группы</option>
                        <?php foreach ($groups as $group): ?>
                            <option value="<?= $group['id'] ?>" <?= $group_id == $group['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($group['group_number']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i> Применить
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Результаты -->
    <div class="card">
        <div class="card-body">
            <?php if ($events): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Дата</th>
                                <th>Время</th>
                                <th>Название</th>
                                <th>Группа</th>
                                <th>Описание</th>
                                <th>Организатор</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($events as $event): ?>
                                <tr>
                                    <td><?= date('d.m.Y', strtotime($event['event_date'])) ?></td>
                                    <td><?= $event['event_time'] ? date('H:i', strtotime($event['event_time'])) : '-' ?></td>
                                    <td><?= htmlspecialchars($event['title']) ?></td>
                                    <td><?= htmlspecialchars($event['group_number']) ?></td>
                                    <td><?= htmlspecialchars($event['description']) ?></td>
                                    <td>
                                        <?php
                                        $stmt = $conn->prepare("SELECT lastName, firstName FROM curators WHERE id = ?");
                                        $stmt->execute([$event['created_by']]);
                                        $creator = $stmt->fetch();
                                        echo htmlspecialchars($creator['lastName'] . ' ' . $creator['firstName']);
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    Нет данных о мероприятиях за выбранный период
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>