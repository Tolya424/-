<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require $_SERVER['DOCUMENT_ROOT'] . '/db.php';

if (!isset($_SESSION['curator_id'])) {
    header("Location: login.php");
    exit();
}

$curator_id = $_SESSION['curator_id'];
$is_admin = $_SESSION['is_admin'] ?? false;

// Получаем данные куратора
$stmt = $conn->prepare("SELECT * FROM curators WHERE id = ?");
$stmt->execute([$curator_id]);
$curator = $stmt->fetch();

// Получаем группы куратора
$stmt = $conn->prepare("SELECT id, group_number FROM student_groups WHERE curator_id = ? ORDER BY group_number");
$stmt->execute([$curator_id]);
$student_groups = $stmt->fetchAll();

// Получаем предстоящие мероприятия (3 ближайших)
$stmt = $conn->prepare("
    SELECT e.*, g.group_number 
    FROM events e
    JOIN student_groups g ON e.group_id = g.id
    WHERE g.curator_id = ? AND e.event_date >= CURDATE()
    ORDER BY e.event_date, e.event_time
    LIMIT 3
");
$stmt->execute([$curator_id]);
$upcoming_events = $stmt->fetchAll();

// Получаем предстоящие кураторские часы (3 ближайших)
$stmt = $conn->prepare("
    SELECT ch.*, g.group_number 
    FROM curator_hours ch
    JOIN student_groups g ON ch.group_id = g.id
    WHERE g.curator_id = ? AND ch.event_date >= CURDATE()
    ORDER BY ch.event_date
    LIMIT 3
");
$stmt->execute([$curator_id]);
$upcoming_hours = $stmt->fetchAll();

// Получаем предстоящие уборки (3 ближайших)
$stmt = $conn->prepare("
    SELECT cl.*, g.group_number 
    FROM cleanings cl
    JOIN student_groups g ON cl.group_id = g.id
    WHERE g.curator_id = ? AND cl.cleaning_date >= CURDATE()
    ORDER BY cl.cleaning_date
    LIMIT 3
");
$stmt->execute([$curator_id]);
$upcoming_cleanings = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет куратора</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2075d0;
            --primary-hover: #1a65b5;
            --sidebar-width: 250px;
            --header-height: 60px;
            --secondary-color: #6c757d;
            --success-color: #28a745;
            --danger-color: #dc3545;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        /* Сайдбар */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background-color: #2c3e50;
            color: white;
            padding-top: var(--header-height);
            transition: all 0.3s;
            z-index: 1000;
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
        }
        
        .sidebar-menu li {
            padding: 10px 15px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-menu li a {
            color: white;
            text-decoration: none;
            display: block;
        }
        
        .sidebar-menu li:hover {
            background-color: rgba(255,255,255,0.1);
        }
        
        .sidebar-menu li.active {
            background-color: var(--primary-color);
        }
        
        /* Основной контент */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: all 0.3s;
        }
        
        /* Шапка */
        .header {
            position: fixed;
            top: 0;
            left: var(--sidebar-width);
            right: 0;
            height: var(--header-height);
            background-color: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 999;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
        }
        
        /* Карточки */
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            border: none;
            transition: transform 0.3s;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .card-header.danger {
            background-color: var(--danger-color);
        }
        
        .card-header.success {
            background-color: var(--success-color);
        }
        
        .card-header.secondary {
            background-color: var(--secondary-color);
        }
        
        /* Кнопки */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
        }
        
        /* Бейджи */
        .badge-primary {
            background-color: var(--primary-color);
        }
        
        /* Адаптивность */
        @media (max-width: 992px) {
            .sidebar {
                left: -var(--sidebar-width);
            }
            
            .main-content, .header {
                margin-left: 0;
            }
            
            .sidebar.active {
                left: 0;
            }
        }
        
        /* Анимации */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .fade-in {
            animation: fadeIn 0.5s ease-out;
        }
        
        /* Профиль */
        .profile-card {
            border-left: 4px solid var(--primary-color);
        }
        
        /* Список */
        .list-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 15px;
            border-radius: 5px;
            margin-bottom: 10px;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            transition: all 0.2s;
        }
        
        .list-item:hover {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .list-item .item-date {
            font-size: 0.9rem;
            color: var(--secondary-color);
        }
        
        .list-item .item-group {
            font-size: 0.9rem;
            background-color: #e9ecef;
            padding: 3px 8px;
            border-radius: 10px;
        }
        
        /* Статистика */
        .stat-card {
            text-align: center;
            padding: 15px;
        }
        
        .stat-card .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .stat-card .stat-label {
            font-size: 0.9rem;
            color: var(--secondary-color);
        }
    </style>
</head>
<body>
    <!-- Сайдбар -->
   <div class="sidebar">
    <!-- Кнопка для мобильной версии -->
   
    
    <ul class="sidebar-menu">
        <li class="active">
            <a href="index.php"><i class="fas fa-home me-2"></i>Главная</a>
        </li>
        <li>
            <a href="events.php"><i class="fas fa-calendar-alt me-2"></i>Мероприятия</a>
        </li>
        <li>
            <a href="curator_hours.php"><i class="fas fa-chalkboard-teacher me-2"></i>Кураторские часы</a>
        </li>
        <li>
            <a href="cleanings.php"><i class="fas fa-broom me-2"></i>Уборки</a>
        </li>
        <li>
            <a href="groups.php"><i class="fas fa-users me-2"></i>Группы</a>
        </li>
        <li>
            <a href="reports.php"><i class="fas fa-chart-bar me-2"></i>Отчеты</a>
        </li>
        <?php if ($is_admin): ?>
        <li>
            <a href="admin.php"><i class="fas fa-cog me-2"></i>Администрирование</a>
        </li>
        <?php endif; ?>
    </ul>
</div>

<style>
    /* Основные стили сайдбара */
    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        width: 250px;
        background-color: #343a40;
        color: white;
        padding: 20px 0;
        transition: transform 0.3s ease;
        z-index: 1000;
        overflow-y: auto;
    }
    
    .sidebar-menu {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .sidebar-menu li a {
        display: block;
        padding: 10px 20px;
        color: rgba(255, 255, 255, 0.8);
        text-decoration: none;
        transition: all 0.3s;
    }
    
    .sidebar-menu li a:hover,
    .sidebar-menu li.active a {
        color: white;
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .sidebar-menu li a i {
        width: 20px;
        text-align: center;
    }
    
    /* Стили для мобильной версии */
    @media (max-width: 992px) {
        .sidebar {
            transform: translateX(-100%);
        }
        
        .sidebar.show {
            transform: translateX(0);
        }
        
        .sidebar-toggle {
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 1001;
            font-size: 1.5rem;
        }
        
        body.sidebar-open {
            padding-left: 250px;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.querySelector('.sidebar');
        const sidebarToggle = document.querySelector('.sidebar-toggle');
        
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            document.body.classList.toggle('sidebar-open');
            
            // Меняем иконку при открытии/закрытии
            const icon = this.querySelector('i');
            if (sidebar.classList.contains('show')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
        
        // Закрываем сайдбар при клике вне его области
        document.addEventListener('click', function(e) {
            if (!sidebar.contains(e.target) && e.target !== sidebarToggle && !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('show');
                document.body.classList.remove('sidebar-open');
                const icon = sidebarToggle.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    });
</script>

    <!-- Шапка -->
    <header class="header">
    
        <div class="d-flex align-items-center">
            <div class="dropdown">
                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-user-circle me-1"></i>
                    <?php echo htmlspecialchars($curator['lastName'] . ' ' . $curator['firstName']); ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                    <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>Профиль</a></li>
                    
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Выйти</a></li>
                </ul>
            </div>
        </div>
    </header>

    <!-- Основной контент -->
    <main class="main-content">
        <div class="container-fluid py-4">
            <!-- Уведомления -->
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show fade-in" role="alert">
                    <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <!-- Приветствие -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card profile-card fade-in">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h4 class="mb-1">Добро пожаловать, <?php echo htmlspecialchars($curator['firstName'] . ' ' . $curator['lastName']); ?>!</h4>
                                    
                                </div>
                                <div class="text-end">
                                    <p class="mb-1">Количество групп: <span class="badge bg-primary"><?php echo count($student_groups); ?></span></p>
                                    <p class="mb-0">Статус: <?php echo $is_admin ? '<span class="badge bg-danger">Администратор</span>' : '<span class="badge bg-primary">Куратор</span>'; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Быстрые действия -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card fade-in">
                        <div class="card-header">
                            <h5 class="card-title mb-0"><i class="fas fa-bolt me-2"></i>Быстрые действия</h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-3 col-6">
                                    <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#addEventModal">
                                        <i class="fas fa-calendar-plus me-2"></i>Мероприятие
                                    </button>
                                </div>
                                <div class="col-md-3 col-6">
                                    <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#addCuratorHourModal">
                                        <i class="fas fa-chalkboard-teacher me-2"></i>Кураторский час
                                    </button>
                                </div>
                                <div class="col-md-3 col-6">
                                    <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#addCleaningModal">
                                        <i class="fas fa-broom me-2"></i>Уборка
                                    </button>
                                </div>
                                <div class="col-md-3 col-6">
                                    <button class="btn btn-outline-primary w-100" data-bs-toggle="modal" data-bs-target="#addGroupModal" >
                                        <i class="fas fa-plus-circle me-2"></i>Добавить группу
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Статистика -->
            <div class="row mb-4">
                <div class="col-md-4 fade-in">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="card-title mb-0"><i class="fas fa-calendar me-2"></i>Мероприятия</h5>
                        </div>
                        <div class="card-body">
                            <div class="stat-card">
                                <div class="stat-value"><?php echo count($upcoming_events); ?></div>
                                <div class="stat-label">Предстоящих мероприятий</div>
                            </div>
                            <a href="events.php" class="btn btn-sm btn-outline-primary w-100 mt-2">Все мероприятия</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 fade-in">
                    <div class="card h-100">
                        <div class="card-header success">
                            <h5 class="card-title mb-0"><i class="fas fa-chalkboard-teacher me-2"></i>Кураторские часы</h5>
                        </div>
                        <div class="card-body">
                            <div class="stat-card">
                                <div class="stat-value"><?php echo count($upcoming_hours); ?></div>
                                <div class="stat-label">Предстоящих часов</div>
                            </div>
                            <a href="curator_hours.php" class="btn btn-sm btn-outline-success w-100 mt-2">Все кураторские часы</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 fade-in">
                    <div class="card h-100">
                        <div class="card-header secondary">
                            <h5 class="card-title mb-0"><i class="fas fa-broom me-2"></i>Уборки</h5>
                        </div>
                        <div class="card-body">
                            <div class="stat-card">
                                <div class="stat-value"><?php echo count($upcoming_cleanings); ?></div>
                                <div class="stat-label">Предстоящих уборок</div>
                            </div>
                            <a href="cleanings.php" class="btn btn-sm btn-outline-secondary w-100 mt-2">Все уборки</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Предстоящие события -->
            <div class="row">
                <!-- Предстоящие мероприятия -->
                <div class="col-lg-4 col-md-6 fade-in">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="card-title mb-0"><i class="fas fa-calendar me-2"></i>Ближайшие мероприятия</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($upcoming_events)): ?>
                                <div class="list-group">
                                    <?php foreach ($upcoming_events as $event): ?>
                                        <div class="list-item">
                                            <div>
                                                <strong><?php echo htmlspecialchars($event['title']); ?></strong>
                                                <div class="item-date">
                                                    <?php echo date('d.m.Y', strtotime($event['event_date'])); ?>
                                                    <?php if ($event['event_time']): ?>
                                                        в <?php echo date('H:i', strtotime($event['event_time'])); ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <span class="item-group"><?php echo htmlspecialchars($event['group_number']); ?></span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <a href="events.php" class="btn btn-sm btn-outline-primary w-100 mt-3">Все мероприятия</a>
                            <?php else: ?>
                                <div class="alert alert-info mb-0">
                                    Нет предстоящих мероприятий
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Предстоящие кураторские часы -->
                <div class="col-lg-4 col-md-6 fade-in">
                    <div class="card h-100">
                        <div class="card-header success">
                            <h5 class="card-title mb-0"><i class="fas fa-chalkboard-teacher me-2"></i>Ближайшие кураторские часы</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($upcoming_hours)): ?>
                                <div class="list-group">
                                    <?php foreach ($upcoming_hours as $hour): ?>
                                        <div class="list-item">
                                            <div>
                                                <strong><?php echo htmlspecialchars($hour['topic']); ?></strong>
                                                <div class="item-date">
                                                    <?php echo date('d.m.Y', strtotime($hour['event_date'])); ?>
                                                </div>
                                            </div>
                                            <span class="item-group"><?php echo htmlspecialchars($hour['group_number']); ?></span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <a href="curator_hours.php" class="btn btn-sm btn-outline-success w-100 mt-3">Все кураторские часы</a>
                            <?php else: ?>
                                <div class="alert alert-info mb-0">
                                    Нет предстоящих кураторских часов
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Предстоящие уборки -->
                <div class="col-lg-4 col-md-6 fade-in">
                    <div class="card h-100">
                        <div class="card-header secondary">
                            <h5 class="card-title mb-0"><i class="fas fa-broom me-2"></i>Ближайшие уборки</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($upcoming_cleanings)): ?>
                                <div class="list-group">
                                    <?php foreach ($upcoming_cleanings as $cleaning): ?>
                                        <div class="list-item">
                                            <div>
                                                <strong><?php echo htmlspecialchars($cleaning['location']); ?></strong>
                                                <div class="item-date">
                                                    <?php echo date('d.m.Y', strtotime($cleaning['cleaning_date'])); ?>
                                                </div>
                                            </div>
                                            <span class="item-group"><?php echo htmlspecialchars($cleaning['group_number']); ?></span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <a href="cleanings.php" class="btn btn-sm btn-outline-secondary w-100 mt-3">Все уборки</a>
                            <?php else: ?>
                                <div class="alert alert-info mb-0">
                                    Нет предстоящих уборок
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Модальные окна -->
    <?php include 'modals.php'; ?>

    <!-- Скрипты -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Переключение сайдбара
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
        
        // Инициализация tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    </script>
</body>
</html>