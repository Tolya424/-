<?php
require_once 'includes/auth_check.php';
require_once 'includes/db.php';
require_once 'includes/header.php';

$page_title = 'Управление группами';

// Получаем список групп
if ($is_admin) {
    // Администратор видит все группы
    $stmt = $conn->prepare("
        SELECT g.*, c.lastName as curator_lastName, c.firstName as curator_firstName 
        FROM student_groups g
        JOIN curators c ON g.curator_id = c.id
        ORDER BY g.group_number
    ");
    $stmt->execute();
} else {
    // Обычный куратор видит только свои группы
    $stmt = $conn->prepare("
        SELECT g.*, c.lastName as curator_lastName, c.firstName as curator_firstName 
        FROM student_groups g
        JOIN curators c ON g.curator_id = c.id
        WHERE g.curator_id = ?
        ORDER BY g.group_number
    ");
    $stmt->execute([$curator_id]);
}

$student_groups_list = $stmt->fetchAll();
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <a href="index.php" class="btn btn-outline-secondary me-2">
                <i class="fas fa-arrow-left me-1"></i> Назад
            </a>
            <h1 class="d-inline-block mb-0">
                <i class="fas fa-users me-2"></i>
                <?= $is_admin ? 'Все группы' : 'Мои группы' ?>
            </h1>
        </div>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addGroupModal">
            <i class="fas fa-plus me-1"></i> Добавить группу
        </button>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if ($student_groups_list): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>№</th>
                                <th>Номер группы</th>
                                <th>Куратор</th>
                                <th>Староста</th>
                                <th>Кол-во студентов</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($student_groups_list as $index => $group): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($group['group_number']) ?></strong>
                                    </td>
                                    <td>
                                        <?= htmlspecialchars($group['curator_lastName'] . ' ' . $group['curator_firstName']) ?>
                                    </td>
                                    <td>
                                        <?= $group['leader_name'] ? htmlspecialchars($group['leader_name']) : '<span class="text-muted">Не указан</span>' ?>
                                    </td>
                                    <td>
                                        <?= $group['students'] ? count(array_filter(explode(',', $group['students']))) : 0 ?>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="group_view.php?id=<?= $group['id'] ?>" class="btn btn-sm btn-outline-primary" title="Просмотр">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="group_edit.php?id=<?= $group['id'] ?>" class="btn btn-sm btn-outline-warning" title="Редактировать">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if ($is_admin || $group['curator_id'] == $curator_id): ?>
                                                <form action="group_delete.php" method="POST" class="d-inline">
                                                    <input type="hidden" name="id" value="<?= $group['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Удалить" onclick="return confirm('Вы уверены, что хотите удалить эту группу?')">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <?= $is_admin ? 'Нет групп в системе' : 'У вас нет групп. Добавьте первую группу.' ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php 
require_once 'includes/modals.php';
require_once 'includes/footer.php';
?>